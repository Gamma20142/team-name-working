The dailyTransactionFile.txt, ticketInfo.txt and userInfo.txt files go in this folder. to run the program type:

java runtime.backEndMain