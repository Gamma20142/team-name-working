#ifndef LOGWRITER_H_INCLUDED
#define LOGWRITER_H_INCLUDED
#include <string>

using namespace std;

class logWriter{
public:
	int writeIn(string message);
};

#endif